// concepts:
// - parsing URLs into components
//     - navigating node docs
// - joining to filepath
// - method=GET vs POST on form
// - processing POST
var http = require('http')
  , fs = require('fs')
  , url = require('url')
  , path = require('path')
  , qs = require('querystring')
  , port = process.argv[2] || 8000

// req object docs -> https://nodejs.org/api/http.html#http_message_url
var server = http.createServer(function(req, res) {
  // get the file from the request
  var file = url.parse( req.url ).pathname
  // small gotcha: '/' should be /index.html
  file = file == '/' ? '/index.html' : file
  // join with filepath
  var filepath = path.join(process.cwd(), file)

  var query = url.parse( req.url ).query
  console.log(query)
  if(query) {
    var data = qs.parse(query)
    console.log(data)
  }

  if(req.method ==="POST") {
    var postdata = ''
    req.on('data', function(d) {
      console.log('hi')
      postdata += d
    })
    req.on('end', function() {
      var data = qs.parse(postdata)
      console.log(data)
    })
  }

  // updated way of checking if file exists
  // TODO could probably use more error checking
  // TODO content type
  fs.access(filepath, fs.R_OK, function(err) {
    if(err) {
      res.writeHead('404', {"Content-type": "text/html"})
      res.end('404 Not Found')
    } else {
      sendFile(res, filepath)
    }
  })

})

function sendFile(res, filepath) {
  res.writeHead('200', {"Content-type": "text/html"})
  var contents = fs.readFileSync(filepath, 'utf8')
  res.end(contents)
}

server.listen(port)
console.log('listening on ' + port)
