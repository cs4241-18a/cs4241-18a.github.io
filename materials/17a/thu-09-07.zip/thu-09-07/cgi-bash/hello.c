#include <stdio.h>

int main() {
printf("Status: 200\n");
printf("Content-Type: text/html\n");
printf("\n");
printf("<html>");
printf("<body>");
printf("<h1>Hello from C!!!!</h1>");
printf("</body>");
printf("</html>");
return 0;
}
