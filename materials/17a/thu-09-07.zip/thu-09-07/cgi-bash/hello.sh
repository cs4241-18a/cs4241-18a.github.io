#!/bin/bash

echo "Status: 200"
echo "Content-Type: text/html"
echo

echo "<html>"
echo "<body>"
echo "<h1>Hello from Bash</h1>"
echo "</body>"
echo "</html>"
