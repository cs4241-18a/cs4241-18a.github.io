var cgi = require('cgi')
var path = require('path')
var http = require('http')

var script = path.resolve(__dirname, 'hello');
http.createServer( cgi(script) ).listen(8007);
