import React from 'react';

class Movie extends React.Component {
  render() {
     const { details } = this.props;
     return (
       <li className="menu-movie">
        <img src={details.image} alt={details.name} />
        <div className="movie-details">
          <h3 className="movie-name">
            {details.name}
            <span className="rating">{details.rating}</span>
          </h3>
          <p>
            {details.desc}
          </p>
        </div>
        </li>
     )
   }
}

export default Movie;

