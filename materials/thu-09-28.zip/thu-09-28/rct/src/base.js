import Rebase from 're-base';

const base = Rebase.createClass({
  apiKey: "AIzaSyBf26KvQWgY7fyXRosbBtgLUQbO6x-RT9Y",
  authDomain: "notflix-2.firebaseapp.com",
  databaseURL: "https://notflix-2.firebaseio.com",
})

export default base;

