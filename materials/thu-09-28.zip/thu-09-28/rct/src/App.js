import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import sampleMovies from './movies.js';
import MovieQueue from './MovieQueue';
import MovieInventory from './MovieInventory';
import base from './base';

class App extends Component {
  constructor() {
    super()
    this.loadSamples = this.loadSamples.bind(this)
    this.addMovie = this.addMovie.bind(this)
    this.updateMovie = this.updateMovie.bind(this)
    this.removeMovie = this.removeMovie.bind(this)
    this.state = {
      movies: {}
    }
  }

  componentWillMount(){
    this.ref = base.syncState('inclass/movies', {
      context: this,
      state: 'movies'
    });
  }

  componentWillUnMount(){
    base.removedBinding(this.ref);
  }
  
  loadSamples() {
    this.setState({
      movies: sampleMovies
    })
  }

  addMovie(movie){
    const movies = {...this.state.movies}
    movies[`movies-${Date.now()}`] = movie;
    this.setState( {movies} )
  }

  updateMovie(key, updatedMovie){
    const movies = {...this.state.movies}
    movies[key] = updatedMovie;
    this.setState( {movies} )
  }

  removeMovie(key){
    const movies = {...this.state.movies}
    delete movies[key] 
    this.setState( {movies} )
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Uber for NotFlix</h1>
        </header>
        <MovieQueue 
          movies={this.state.movies}
          loadSamples={this.loadSamples}
        />
        <MovieInventory 
          movies={this.state.movies}
          addMovie={this.addMovie}
          updateMovie={this.updateMovie}
          removeMovie={this.removeMovie}
        />
      </div>
    );
  }
}

export default App;
