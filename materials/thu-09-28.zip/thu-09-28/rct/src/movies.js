// This is just some sample data so you don't have to think of your own!
module.exports = {
  movie1: {
    name: 'Game of Thrones',
    image: 'https://images-na.ssl-images-amazon.com/images/M/MV5BMjE3NTQ1NDg1Ml5BMl5BanBnXkFtZTgwNzY2NDA0MjI@._V1_UX182_CR0,0,182,268_AL_.jpg',
    desc: 'You live of you die.',
    rating: 5,
    status: 'available'
  },

  movie2: {
    name: 'It',
    image: 'https://images-na.ssl-images-amazon.com/images/M/MV5BOTE0NWEyNDYtYWI5MC00MWY0LTg1NDctZjAwMjkyMWJiNzk1XkEyXkFqcGdeQXVyNjk5NDA3OTk@._V1_UX182_CR0,0,182,268_AL_.jpg',
    desc: 'Nope.',
    rating: 4,
    status: 'available'
  },

  movie3: {
    name: 'Wonder Woman',
    image: 'https://images-na.ssl-images-amazon.com/images/M/MV5BNDFmZjgyMTEtYTk5MC00NmY0LWJhZjktOWY2MzI5YjkzODNlXkEyXkFqcGdeQXVyMDA4NzMyOA@@._V1_UX182_CR0,0,182,268_AL_.jpg',
    desc: 'Woo!',
    rating: 5,
    status: 'available'
  }
};

