import React from 'react';

class AddMovieForm extends React.Component {
 createMovie(event) {
   event.preventDefault();

   const movie = {
     name: this.name.value,
     rating: this.rating.value,
     desc: this.desc.value,
     image: this.image.value
   }

   this.props.addMovie(movie);
   this.movieForm.reset();
 }
 render() {
   return (
      <form ref={(input) => this.movieForm = input} className="movie-edit" onSubmit={(e) => this.createMovie(e)}>
        <input ref={(input) => this.name = input} type="text" placeholder="Movie Name" />
        <select ref={(input) => this.rating = input}>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select>
        <br />
        <textarea ref={(input) => this.desc = input} placeholder="Movie Desc"></textarea>
        <br />
        <input ref={(input) => this.image = input} type="text" placeholder="Movie Image" />
        <br />
        <button type="submit">+ Add Item</button>
      </form>
   )
 }
}

export default AddMovieForm;
