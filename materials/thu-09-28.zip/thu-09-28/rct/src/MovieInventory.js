import React from 'react';
import AddMovieForm from './AddMovieForm';

class MovieInventory extends React.Component {
 constructor() {
   super();
   this.renderMovieForm = this.renderMovieForm.bind(this);
 }
 handleChange(e, key) {
   const movie = this.props.movies[key] // IT WAS movieS
   const updatedMovie = { ...movie, [e.target.name]: e.target.value }
   this.props.updateMovie(key, updatedMovie);
 }
 renderMovieForm(key) {
   const movie = this.props.movies[key]
   return(
    <div className='movie-form' key={key}>
      <input name='name' 
        value={movie.name} 
        type='text'
        placeholder='Movie Name'
        onChange={(e) => this.handleChange(e, key)}
      />
      <input name='image' 
        value={movie.image} 
        type='text'
        placeholder='Movie Image'
        onChange={(e) => this.handleChange(e, key)}
      />
      <input name='desc' 
        value={movie.desc} 
        type='text'
        placeholder='Movie Desc'
        onChange={(e) => this.handleChange(e, key)}
      />      
      <select name='rating' 
        value={movie.rating} 
        onChange={(e) => this.handleChange(e, key)}
      >
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
      </select>
      <button onClick={() => this.props.removeMovie(key)}>Remove Movie</button>
    </div>
   )
 }
 render() {
    return (
       <div>
       <h2>Movie Editable Inventory</h2>
       {Object.keys(this.props.movies).map(this.renderMovieForm)}
       <h2>Movie Add</h2>
       <AddMovieForm addMovie={this.props.addMovie}/>
       </div>
    )
  }
 }

export default MovieInventory;
