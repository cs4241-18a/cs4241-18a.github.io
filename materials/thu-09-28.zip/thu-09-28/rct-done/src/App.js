import React, { Component } from 'react';
import logo from './logo.svg';
import MovieQueue from './MovieQueue';
import MovieInventory from './MovieInventory';
import sampleMovies from './movies.js'
import base from './base';
import './App.css';

class App extends Component {
  constructor() {
    super()
    this.loadSamples = this.loadSamples.bind(this)
    this.addMovie = this.addMovie.bind(this)
    this.updateMovie = this.updateMovie.bind(this)
    this.removeMovie = this.removeMovie.bind(this)
    this.state = {
      movies: {}
    }
  }

  componentWillMount() {
   this.ref = base.syncState(`tonight/movies`, {
     context: this,
     state: 'movies'
   });
  }

  componentWillUnMount() {
    base.removeBinding(this.ref);
  }

  loadSamples() {
    this.setState({
      movies: sampleMovies
    })
  }

	addMovie(movie) {
	 const movies = {...this.state.movies};
	 movies[`movie-${Date.now()}`] = movie;
	 this.setState({ movies })
  }

	removeMovie(key) {
	 const movies = {...this.state.movies};
   //movies[key] = null;
	 delete movies[key];
	 this.setState({ movies })
  }

	updateMovie(key, updatedMovie) {
   const movies = {...this.state.movies};
   movies[key] = updatedMovie;
   this.setState({ movies })
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">NotFlix</h1>
        </header>
        <MovieQueue 
          movies={this.state.movies}
          loadSamples={this.loadSamples}
        />
        <MovieInventory 
          addMovie={this.addMovie}
          updateMovie={this.updateMovie}
          removeMovie={this.removeMovie}
          movies={this.state.movies}
        />
      </div>
    );
  }
}

export default App;
