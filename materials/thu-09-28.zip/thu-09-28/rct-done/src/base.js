import Rebase from 're-base';

const base = Rebase.createClass({
  apiKey: "AIzaSyBAuok936KRPvZU995MD_sUdfUjjE_Xgb4",
  authDomain: "notflix-7ff62.firebaseapp.com",
  databaseURL: "https://notflix-7ff62.firebaseio.com",
})

export default base;

