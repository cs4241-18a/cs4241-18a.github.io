import React from 'react';
import Movie from './Movie';

class MovieQueue extends React.Component {
 constructor() {
   super()
 }
 render() {
    return (
     <div>
       <h2>MovieQueue</h2>
       <button onClick={this.props.loadSamples}>Load Sample Movies</button>
       <ul className="list-of-movies">
         {
           Object.keys(this.props.movies)
           .map(key => 
           <Movie 
             key={key} 
             index={key} 
             details={this.props.movies[key]} 
           />)
         }
       </ul>
     </div>
    )
  }
 }

export default MovieQueue;

