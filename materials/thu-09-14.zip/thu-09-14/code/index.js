var http = require('http')
  , fs = require('fs')
  , url = require('url')
  , path = require('path')

var server = http.createServer (function (req, res) {
  var uri = url.parse(req.url);

  switch( uri.pathname ) {
    case '/':
      sendFile(res, 'index.html');
      break;
    case '/index.html':
      sendFile(res, 'index.html');
      break;
    case '/flights':
      sendJSON(res, 'flights-3m.json');
      break;
    default:
      res.end('404 not found');
  }
});

function handleResBody(req) {
 var chunk = ""
 req.on('data', function(data) {
   chunk += data;
 })
 req.on('end', function(data) {
   // Note: this is not a great way to access this object.
   var obj = chunk.split('=');
   classes.push( obj[1] );
 })
}

server.listen(9091);
console.log('listening on 9091');

// subroutines
//
function sendJSON(res, filename) {
  res.writeHead(200, {'Content-type': 'application/json'})

  var stream = fs.createReadStream(filename)

  stream.on('data', function(data) {
    res.write(data);
  })

  stream.on('end', function(data) {
    res.end();
    return;
  })
}

function sendFile(res, filename) {
  res.writeHead(200, {'Content-type': 'text/html'})

  var stream = fs.createReadStream(filename)

  stream.on('data', function(data) {
    res.write(data);
  })

  stream.on('end', function(data) {
    res.end();
    return;
  })
}
