var compiled = _.template(
  "<div class='flight'>" + 
    "<h2><%= origin %></h2>" + 
    "<p><%= destination %></p>" + 
    "<p><%= delay %></p>" + 
  "</div>"
);
